import project from "./schema/project";
import user from "./schema/user";
import wallet from "./schema/wallet";

export default {
	project,
	user,
	wallet,
};
